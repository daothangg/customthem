<?php
namespace Magebees\Finder\Controller\Adminhtml\Finder;

class UniversalProductGrid extends Universaltab
{

}
