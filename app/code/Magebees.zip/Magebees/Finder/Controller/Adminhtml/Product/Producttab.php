<?php

namespace Magebees\Finder\Controller\Adminhtml\Product;

class Producttab extends Tab
{
    
}
