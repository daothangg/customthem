var config = {
    map: {
        '*': {
            cwsfinder: 'Magebees_Finder/js/finder'
        }
    }
};
