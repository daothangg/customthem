<?php
namespace Magecomp\Firstdataicici\Helper;
use \Magento\Store\Model\ScopeInterface;
use \Magento\Framework\App\Helper\AbstractHelper;

class Data extends AbstractHelper
{
    const FIRSTDATA_TRANSACTION_MODE = "payment/firstdataicici/mode";
    const FIRSTDATA_TRANSACTION_TYPE = "payment/firstdataicici/transtype";
    const FIRSTDATA_SECRET_KEY = "payment/firstdataicici/secret_key";
    const FIRSTDATA_STORE_ID = "payment/firstdataicici/icistore_id";
    const FIRSTDATA_ORDER_STATUS = "payment/firstdataicici/order_status";
    const FIRSTDATA_ORDER_STATUS_FAIL = "payment/firstdataicici/order_status_fail";
    const FIRSTDATA_CURRENCY = "payment/firstdataicici/currency";
    const FIRSTDATA_LANGUAGE = "payment/firstdataicici/language";
    const FIRSTDATA_TIMEZONE = "general/locale/timezone";

	public function __construct(
	    \Magento\Framework\App\Helper\Context $context,
	    \Magento\Payment\Model\PaymentMethodList $paymentmethod,
	    \Magento\Store\Model\StoreManagerInterface $storeManager,
	    \Magento\Checkout\Model\Session $checkoutSession
	    
	){
		parent::__construct($context);
		$this->paymentmethod = $paymentmethod;
		$this->storeManager = $storeManager;
		$this->checkoutSession = $checkoutSession;
        
	}
	
	public function checkFirstDataPay() {
	    $storeId = $this->storeManager->getStore()->getId();
	    $shippingMethod = $this->checkoutSession->getQuote()->getShippingAddress()->getShippingMethod();
        $result = $this->paymentmethod->getActiveList($storeId);
        
        $check_store_delivery = $this->scopeConfig->getValue('other_configuration/hide_payment_firstdata/delivery', ScopeInterface::SCOPE_STORE);
        $check_store_collection = $this->scopeConfig->getValue('other_configuration/hide_payment_firstdata/collection', ScopeInterface::SCOPE_STORE);
        foreach ($result as $key=>$_result) {
            if ($_result->getCode() == "firstdataicici" && $check_store_collection == '1' && $shippingMethod === 'freeshipping_freeshipping') {
                return false;
            }else if($_result->getCode() == "firstdataicici" && $check_store_delivery == '1' && $shippingMethod === 'flatrate_flatrate'){
                 return false;
            }
            else if($_result->getCode() == "firstdataicici" && $check_store_collection == '0' && $shippingMethod === 'freeshipping_freeshipping') {
                return true;
            }
            else if($_result->getCode() == "firstdataicici" && $check_store_delivery == '0' && $shippingMethod === 'flatrate_flatrate') {
                return true;
            }
            else if($_result->getCode() == "firstdataicici" && $check_store_delivery == '0' && $check_store_collection === '0') {
                return true;
            }
            else if($_result->getCode() == "stripe_payments_checkout_card") {
                return true;
            }
        }
        return false;
	}
	
	public function getTransactionMode() {
        return $this->scopeConfig->getValue(self::FIRSTDATA_TRANSACTION_MODE,ScopeInterface::SCOPE_STORE);
	}
    public function getTransactionType()
    {
        return $this->scopeConfig->getValue(self::FIRSTDATA_TRANSACTION_TYPE,ScopeInterface::SCOPE_STORE);
    }

    public function getSecretKey()
    {
		return $this->scopeConfig->getValue(self::FIRSTDATA_SECRET_KEY,ScopeInterface::SCOPE_STORE);
	}

    public function getICIStoreId()
    {
        return $this->scopeConfig->getValue(self::FIRSTDATA_STORE_ID,ScopeInterface::SCOPE_STORE);
	}

    public function getNewOrderStatus()
    {
        return $this->scopeConfig->getValue(self::FIRSTDATA_ORDER_STATUS,ScopeInterface::SCOPE_STORE);
    }
    public function getOrderStatusFail()
    {
        return $this->scopeConfig->getValue(self::FIRSTDATA_ORDER_STATUS_FAIL,ScopeInterface::SCOPE_STORE);
    }

    public function getCurrency()
    {
        return $this->scopeConfig->getValue(self::FIRSTDATA_CURRENCY,ScopeInterface::SCOPE_STORE);
    }

    public function getLanguage()
    {
        return $this->scopeConfig->getValue(self::FIRSTDATA_LANGUAGE,ScopeInterface::SCOPE_STORE);
    }
    public function getCurrentTimezone()
    {
        return $this->scopeConfig->getValue(self::FIRSTDATA_TIMEZONE,ScopeInterface::SCOPE_STORE);
    }
}
