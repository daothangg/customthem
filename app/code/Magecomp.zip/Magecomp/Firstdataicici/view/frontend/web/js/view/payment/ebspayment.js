define(
    [
        'uiComponent',
        'Magento_Checkout/js/model/payment/renderer-list'
    ],
    function (
        Component,
        rendererList
    ) {
        'use strict';
        rendererList.push(
            {
                type: 'firstdataicici',
                component: 'Magecomp_Firstdataicici/js/view/payment/method-renderer/ebspayment-method'
            }
        );
        /** Add view logic here if needed */
        return Component.extend({});
    }
);