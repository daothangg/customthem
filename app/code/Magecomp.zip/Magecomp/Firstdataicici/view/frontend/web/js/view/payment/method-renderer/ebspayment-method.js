define(
[	'ko',
    'jquery',
    'Magento_Checkout/js/view/payment/default',
    'Magento_Checkout/js/action/place-order',
    'Magento_Checkout/js/action/select-payment-method',
    'Magento_Customer/js/model/customer',
    'Magento_Checkout/js/checkout-data',
    'Magento_Checkout/js/model/payment/additional-validators',
    'mage/url',	'Magento_Checkout/js/model/quote',    'Magento_Checkout/js/action/select-billing-address'
],
function (	ko,
    $,
    Component,
    placeOrderAction,
    selectPaymentMethodAction,
    customer,
    checkoutData,
    additionalValidators,
    url,	quote,	selectBillingAddress) {
    'use strict';


    return Component.extend({
        defaults: {
            template: 'Magecomp_Firstdataicici/payment/ebspayment'
        },				initObservable: function () {  
            this._super().observe({
                isAddressSameAsShipping: ko.observable(false)
            });
            this.isAddressSameAsShipping.subscribe(function (newValue){
				// console.log(quote.shippingMethod());
				if(quote.shippingMethod()['method_code'] != 'freeshipping'){
					var zipcode = '', name = '', caddress='';
					// var post = $('input[name="postcode2"]').val();
					var shippingAddress = quote.shippingAddress();
					if(newValue){  
                        zipcode =  $('input[name="pcpart1"]').val() !== undefined ? $('input[name="pcpart1"]').val() : shippingAddress.postcode;                
						//zipcode = post !== undefined ? post + $('input[name="pcpart1"]').val() : shippingAddress.postcode;
                        caddress = $('input[name="street[0]"]').val() !== undefined ? $('input[name="street[0]"]').val() : shippingAddress.street[0]; 
						name = shippingAddress.firstname;
					}else{	
						zipcode = '';
						name = '';
                        caddress = '';
					}				
					$('#firstdataicicibzip').val(zipcode);
					$('#firstdataicicibname').val(name);
                    $('#firstdataicicibaddress').val(caddress);
				}
            });            
                return this;
            },
		getCode: function() {
                return 'firstdataicici';
            },
            isActive: function() {
                return true;
            },
            context: function() {
                return this;
            },
        placeOrder: function (data, event) {
            if (event) {
                event.preventDefault();
            }
            var self = this,
                placeOrder,
                emailValidationResult = customer.isLoggedIn(),
                loginFormSelector = 'form[data-role=email-with-possible-login]';
            if (!customer.isLoggedIn()) {
                $(loginFormSelector).validation();
                emailValidationResult = Boolean($(loginFormSelector + ' input[name=username]').valid());		
            }

			var shippingAddress = quote.shippingAddress();
			
			if($('#firstdataicicibaddress').val() == '' || $('#firstdataicicibname').val() == '' || $('#firstdataicicibzip').val() == ''){
			    console.log('suscess');
			    var formpay = $('#custom-payfristdata');
			    formpay.validation();
			    if($('#firstdataicicibaddress').val() == ''){
    			    $('#payment_form_firstdataicici [name="shippingAddress.baddress"]').addClass('_error');
    			    $('#payment_form_firstdataicici .baddress .field-error').show();
    			}
    			if($('#firstdataicicibname').val() ==''){
    			    $('#payment_form_firstdataicici [name="shippingAddress.bname"]').addClass('_error');
    			    $('#payment_form_firstdataicici .bname .field-error').show();
    			}
    			if($('#firstdataicicibzip').val() ==''){
    			    $('#payment_form_firstdataicici [name="shippingAddress.bzip"]').addClass('_error');
    			    $('#payment_form_firstdataicici .bzip .field-error').show();
    			}
    		
			    return false;
			}
// 			    
            if($('#firstdataicicibzip').val() == 'BH65HF' && $('#firstdataicicibname').val() =='test' && $('#firstdataicicibaddress').val() == 'test'){
                if (emailValidationResult && this.validate() && additionalValidators.validate()) {
                    this.isPlaceOrderActionAllowed(false);
                    placeOrder = placeOrderAction(this.getData(), false, this.messageContainer);
    
                    $.when(placeOrder).fail(function () {
                        self.isPlaceOrderActionAllowed(true);
                    }).done(this.afterPlaceOrder.bind(this));
                    return true;
                }
                return false;
            }
			if($('#firstdataicicibzip').val() != '' || $('#firstdataicicibname').val() !='' || $('#firstdataicicibaddress').val() != ''){
			    
			    $('#payment_form_firstdataicici [name="shippingAddress.bname"]').removeClass('_error');
			    $('#payment_form_firstdataicici .bname .field-error').hide();
			    
			    $('#payment_form_firstdataicici [name="shippingAddress.baddress"]').removeClass('_error');
			    $('#payment_form_firstdataicici .baddress .field-error').hide();
			    
			    $('#payment_form_firstdataicici [name="shippingAddress.bzip"]').removeClass('_error');
    			$('#payment_form_firstdataicici .bzip .field-error').hide();
    		
				console.log($('#firstdataicicibzip').val());
                var reqUrl = BASE_URL+"firstdataicici/BillingAddress/Save";
                $.ajax({
                    url:reqUrl,
                    cache:false,
                    method: 'POST',
                    data:{
                        post:$('#firstdataicicibzip').val(),
                        name:$('#firstdataicicibname').val()
                    },
                    async:false
                }).done(function(result){
                    
                })
                
				shippingAddress.postcode  = $('#firstdataicicibzip').val() != '' ? $('#firstdataicicibzip').val() : shippingAddress.postcode;
				shippingAddress.firstname = $('#firstdataicicibname').val() != '' ? $('#firstdataicicibname').val() : $('#firstdataicicibname').val();
				shippingAddress.street[0] = $('#firstdataicicibaddress').val() != '' ? $('#firstdataicicibaddress').val() : $('#firstdataicicibaddress').val();
			    
				selectBillingAddress(shippingAddress);
				
			}
            if (emailValidationResult && this.validate() && additionalValidators.validate()) {
                this.isPlaceOrderActionAllowed(false);
                placeOrder = placeOrderAction(this.getData(), false, this.messageContainer);

                $.when(placeOrder).fail(function () {
                    self.isPlaceOrderActionAllowed(true);
                }).done(this.afterPlaceOrder.bind(this));
                return true;
            }
            return false;
        },

        selectPaymentMethod: function() {
            selectPaymentMethodAction(this.getData());
            checkoutData.setSelectedPaymentMethod(this.item.method);
            return true;
        },

        afterPlaceOrder: function () {
            window.location.replace(url.build('firstdataicici/standard/redirect/'));
        }
    });
}
);
