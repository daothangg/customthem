<?php
namespace Magecomp\Firstdataicici\Block\Standard;
use \Magento\Framework\View\Element\Template\Context;
use \Magento\Customer\Model\Session;
use \Magento\Framework\ObjectManagerInterface;
use \Magecomp\Firstdataicici\Model\Payment;
use \Magecomp\Firstdataicici\Helper\Data;
use \Magento\Store\Model\StoreManagerInterface;

class Redirect extends \Magento\Framework\View\Element\AbstractBlock
{
	protected $checkoutSession;
	protected $standardFactory;
	protected $_helper;
	protected $storeManager;
	
	protected $_methodCode = 'firstdataicici';

	public function __construct(Context $context, Payment $standardFactory,StoreManagerInterface $storeManager, Data $helper, Session $checkoutSession, ObjectManagerInterface $objectManager,array $data = [])
	{
		$this->_helper = $helper;
		$this->standardFactory = $standardFactory;
		$this->checkoutSession = $checkoutSession;
		$this->storeManager = $storeManager;
		parent::__construct($context, $data);
	}
	
	public function getMethodCode() {
        return $this->_methodCode;
    }
  
	protected function _toHtml() {
		$standard = $this->standardFactory;
		$gatewayUrl=$standard->getGatewayUrl();
		$html = "";
        if($this->getOrder()->getState()==\Magento\Sales\Model\Order::STATE_NEW){
    		$params = $standard->setOrder($this->getOrder())->getStandardCheckoutFormFields();
           
    		$fields = "";
    
    		foreach ($params as $key => $val)
    		{
    			$fields .= '<input type="hidden" name="'.$key.'" value="'.$val.'" />';
    		}
            $html = '<html><body><form name="icicifirstdata" id="icicifirstdata" action="'. $gatewayUrl .'" method="POST">';
    		$html .= $fields;
    
            $html .= 'You are being redirected to First Data Connect Payment Services secure online payments.';
            $html .= '</form><script type="text/javascript">setTimeout(function(){document.getElementById("icicifirstdata").submit()},500)</script>';
            $html .= '</body></html>';
        }
        return $html;
    }
}