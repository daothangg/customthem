<?php
namespace Magecomp\Firstdataicici\Block;

class Form extends \Magento\Payment\Block\Form
{
	protected $_template = 'Magecomp_Firstdataicici::form.phtml';
	
    protected $_methodCode = 'firstdataicici';

	public function getMethodCode() {
        return $this->_methodCode;
    }
}