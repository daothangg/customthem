<?php
namespace Magecomp\Firstdataicici\Controller\Standard;

use Magento\Framework\View\Result\PageFactory;
use Magento\Framework\App\Action\Context;
use Magento\Sales\Model\Order;
use Magento\Checkout\Model\Session;
use Magento\Framework\Controller\ResultFactory;
use Magento\Framework\Data\Form\FormKey;
use Magento\Framework\App\Request\Http;
use \Magecomp\Firstdataicici\Helper\Data;
		
class Failure extends \Magento\Framework\App\Action\Action
{
	protected $_order;
	protected $order;
	protected $pageFactory;
	protected $salesOrder;
	protected $checkoutSession;
    protected $request;
    protected $formKey;
	
    public function __construct(Context $context, PageFactory $pageFactory,
                                Order $salesOrder, Session $checkoutSession,
                                FormKey $formKey, Http $request,Data $helper)
    {
        $this->pageFactory = $pageFactory;
        $this->order = $salesOrder;
        $this->checkoutSession = $checkoutSession;
        $this->request = $request;
        $this->helper = $helper;
        $this->formKey = $formKey;
        $this->request->setParam('form_key', $this->formKey->getFormKey());
        return parent::__construct($context);
    }
	
	public function execute() {
        $errorMsg = __('Your Payment did not go through. Please try again .');
        $order = $this->getOrder();
		if (!$order->getId()) {
            $this->norouteAction();
            return;
        }

        if ($order->getId()) {
            $order->addStatusToHistory($order->getStatus(), $errorMsg);
            $order->cancel();
            $order->save();
        }
        $order->setStatus($this->helper->getOrderStatusFail());
        $order->save();
		$resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);
		$this->messageManager->addError($errorMsg);
        $resultRedirect->setPath('checkout/cart');
    	return $resultRedirect;
    }    
		
	public function getOrder()
	{
         $orderId = $this->checkoutSession->getLastOrderId();

		$order = $this->order->load($orderId);
		return $order;
	}
}
