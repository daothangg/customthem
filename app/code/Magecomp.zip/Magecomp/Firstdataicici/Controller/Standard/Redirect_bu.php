<?php
namespace Magecomp\Firstdataicici\Controller\Standard;

use \Magento\Framework\View\Result\PageFactory;
use \Magento\Framework\App\Action\Context;
use \Magento\Sales\Model\Order;
use \Magento\Checkout\Model\Session;
use \Magecomp\Firstdataicici\Helper\Data;
use \Magento\Framework\Controller\ResultFactory;

class Redirect extends \Magento\Framework\App\Action\Action
{
	protected $order;
	protected $pageFactory;
	protected $salesOrder;
	protected $checkoutSession;
	protected $helper;
	
    public function __construct(Context $context, PageFactory $pageFactory, Data $helper, Order $salesOrder, Session $checkoutSession)
    {
		$this->helper = $helper;
        $this->pageFactory = $pageFactory;
        $this->order = $salesOrder;
        $this->checkoutSession = $checkoutSession;
        return parent::__construct($context);
    }
	
	public function execute() {
		return $this->redirect();
    }
	
	public function getOrder()
	{
	   $orderId = $this->checkoutSession->getLastOrderId();
	   return $this->order->load($orderId);
	}

    public function redirect()
    {
		$resultPage = $this->resultFactory->create(ResultFactory::TYPE_PAGE);
		$this->checkoutSession->setICICIQuoteId($this->checkoutSession->getQuoteId());
		
		$order = $this->getOrder();
		
		if (!$order->getId())
        {
            $this->norouteAction();
            return;
        }
        
		if ($order->getState() != \Magento\Sales\Model\Order::STATE_NEW)
        {
            $this->norouteAction();
            return;
        }
        
	    $order->setStatus($this->helper->getOrderStatusFail());
		$order->addStatusToHistory($this->helper->getOrderStatusFail(),__('Customer was redirected to First Data ICICI Service'));
		$order->setCreatedAt(date('Y-m-d H:i:s',strtotime('+1 hour',strtotime($order->getCreatedAt()))));
        $order->save();
	
        $this->getResponse()->setBody($resultPage->getLayout()->createBlock('\Magecomp\Firstdataicici\Block\Standard\Redirect')->setOrder($order)->toHtml());

		$this->checkoutSession->unsQuoteId();
	}
}

