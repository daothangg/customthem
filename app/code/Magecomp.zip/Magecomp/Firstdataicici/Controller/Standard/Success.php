<?php
namespace Magecomp\Firstdataicici\Controller\Standard;

use Magento\Framework\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;
use Magento\Sales\Model\Order;
use Magento\Checkout\Model\Session;
use Magento\Framework\Controller\ResultFactory;
use Magento\Sales\Model\Order\Email\Sender\OrderSender;
use Magento\Sales\Model\Order\Email\Sender\InvoiceSender;
use Magento\Sales\Model\Service\InvoiceService;
use Magento\Framework\DB\Transaction;
use Magecomp\Firstdataicici\Helper\Data;
use Magento\Framework\Data\Form\FormKey;
use Magento\Framework\App\Request\Http;
use Magento\Framework\Pricing\Helper\Data as PriceingHelper;
		
class Success extends \Magento\Framework\App\Action\Action
{
	protected $_order;
	protected $order;
	protected $helper;
	protected $pageFactory;
	protected $salesOrder;
	protected $orderSender;
	protected $invoiceSender;
	protected $invoiceService;
	protected $dbTransection;
	protected $checkoutSession;
	protected $priceingHelper;

	protected $request;
	protected $formKey;
	
	protected $inlineTranslation;
    protected $_storeManager;
    protected $_transportBuilder;
    protected $_scopeConfig;
    public $dataHelper;
    public $curHelper;

	public function __construct(
	    Context $context, PageFactory $pageFactory,
		Data $helper, OrderSender $orderSender,
		Order $salesOrder, Session $checkoutSession,
		InvoiceSender $invoiceSender,
		InvoiceService $invoiceService,
		Transaction $dbTransection,
		FormKey $formKey,
		Http $request,
		PriceingHelper $priceingHelper,
		\Magento\Framework\Translate\Inline\StateInterface $inlineTranslation,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Framework\Mail\Template\TransportBuilder $transportBuilder,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \David\Config\Helper\Data $dataHelper,
        \Magento\Sales\Model\Order\Address\Renderer $renderer,
        \Magento\Framework\Stdlib\DateTime\DateTime $date,
        \Magento\Framework\Pricing\Helper\Data $curHelper,
        \Magento\Sales\Api\OrderRepositoryInterface $orderRepository,
        \Magento\Sales\Model\ResourceModel\Order\CollectionFactory $collectionFactory,
        \Magento\Framework\Pricing\Helper\Data $pricingHelper,
        \Magento\Framework\App\CacheInterface $cache,
		\Magento\Quote\Model\QuoteFactory $quoteFactory,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory,
        \Magento\Sales\Model\ResourceModel\Order $orderResourceModel
    )
    {
        $this->pageFactory = $pageFactory;
		$this->helper = $helper;
        $this->order = $salesOrder;
		$this->orderSender = $orderSender;
		$this->invoiceSender = $invoiceSender;
		$this->invoiceService = $invoiceService;
		$this->dbTransection  = $dbTransection;
        $this->checkoutSession = $checkoutSession;
		$this->priceingHelper = $priceingHelper;

		$this->request = $request;
		$this->formKey = $formKey;
		
		$this->inlineTranslation = $inlineTranslation;
        $this->_storeManager = $storeManager;
        $this->_transportBuilder = $transportBuilder;
        $this->_scopeConfig = $scopeConfig;
        $this->dataHelper = $dataHelper;
        $this->addressRenderer = $renderer;
        $this->date= $date;
        $this->curHelper = $curHelper;
        $this->orderResourceModel = $orderResourceModel;
        $this->orderRepository = $orderRepository;
        $this->pricingHelper = $pricingHelper;
        $this->cache = $cache;
		$this->quoteFactory = $quoteFactory;
         $this->_resultPageFactory = $resultPageFactory;
        $this->collectionFactory = $collectionFactory;
		
		$this->request->setParam('form_key', $this->formKey->getFormKey());
        return parent::__construct($context);
    }
	
	public function execute() {
    	$response = $this->getRequest()->getPostValue();
		$resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);
		$orderSender = $this->orderSender;
		$formattedPrice =$this->priceingHelper->currency($response['chargetotal'], true, false);
$writer = new \Zend_Log_Writer_Stream(BP . '/var/log/firstdata.log');
$logger = new \Zend_Log();
$logger->addWriter($writer);
$logger->info('$response');
$logger->info(print_r($response, true));

		if($response['processor_response_code'] == 00 && $response['status']=="APPROVED")
		{
			$this->checkoutSession->setQuoteId($this->checkoutSession->getSecureebsStandardQuoteId());
    		$this->checkoutSession->unsSecureebsStandardQuoteId();

    		$order = $this->getOrder($response['oid']);
    		
$logger->info('$order Id : ' . $order->getId());
			$orderState = \Magento\Sales\Model\Order::STATE_PROCESSING;
            $order->setState($orderState)->setStatus($this->helper->getNewOrderStatus());

    		if (!$order->getId()) {
    			$resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);
        		$this->messageManager->addError($errorMsg);
                $resultRedirect->setPath('checkout/cart');
            	return $resultRedirect;
    			return;
    		}
			$msg = __('Captured amount of %1 online. Transaction ID: "%2".',$formattedPrice,$response['endpointTransactionId']);
    		$order->addStatusToHistory($order->getStatus(),$msg);
    		$order->save();
			$orderSender->send($order);

			// Invoice Generation Code
			// if($this->helper->getNewOrderStatus()==\Magento\Sales\Model\Order::STATE_PROCESSING)
			// {
				if ($order->canInvoice()) {
					// Create invoice for this order
					$invoice = $this->invoiceService->prepareInvoice($order);
					// Make sure there is a qty on the invoice
					if (!$invoice->getTotalQty()) {
						throw new \Magento\Framework\Exception\LocalizedException(
							__('You can\'t create an invoice without products.')
						);
					}
					// Register as invoice item
					$invoice->setRequestedCaptureCase(\Magento\Sales\Model\Order\Invoice::CAPTURE_OFFLINE);
					$invoice->register();

					// Save the invoice to the order
					$transaction = $this->dbTransection
						->addObject($invoice)
						->addObject($invoice->getOrder());

					$transaction->save();
					$this->invoiceSender->send($invoice);

					$order->addStatusHistoryComment(
						__('Notified customer about invoice #%1.', $invoice->getIncrementId())
					)
						->setIsCustomerNotified(true)
						->save();
				}
			// }
			// Invoice Generation Code
			$this->sendEmailAfterPlace($order);
			

			$resultRedirect->setPath('checkout/onepage/success');
    		return $resultRedirect;
		} else {
			$resultRedirect->setPath('firstdataicici/standard/failure');
    		return $resultRedirect;
		}
	}
	
    public function getOrder($incrementId)
	{
		$order = $this->order->loadByIncrementId($incrementId);
		$this->checkoutSession->setLastRealOrderId($order->getIncrementId());
		$this->checkoutSession->setLastSuccessQuoteId($order->getQuoteId());
		$this->checkoutSession->setLastQuoteId($order->getQuoteId());
		$this->checkoutSession->setLastOrderId($order->getId());
		return $order;
	}
	
	public function sendEmailAfterPlace($order){
        $storeId =  $this->_storeManager->getStore()->getId();
        $isNewOrderEnable = $this->dataHelper->getConfigVal('sales_email/order/enabled');
        if($isNewOrderEnable){
            $identifierdelivery = 'delivery';
    		$delivery_time 	= $this->cache->load($identifierdelivery);
    
    		$quote = $this->quoteFactory->create()->load($order->getQuoteId());
            if ($quote) {
            	$quote->setData('customer_delivery_time',$delivery_time);
            	$quote->save();
            }
            
    	    $order->setData('customer_delivery_time', $delivery_time);
    	    $order->save();
    	    
    	    $time = $this->date->date('Y-m-d H:i:s');
            //$order->setCreatedAt($time);
            // $this->orderRepository->save($order);
    
            $orderIncId = $order->getIncrementId();
            // Set email config options
            $store = $this->_storeManager->getStore();
            $from = $this->dataHelper->getConfigVal('sales_email/order/identity');
            $to = [
                'email' => explode(",",$this->dataHelper->getConfigVal('sales_email/order/copy_to')),
                'name' => 'Administrator'
            ];
            
            $bonusTime = $this->_scopeConfig->getValue('deliveryoption/time_notice/time_delivery',\Magento\Store\Model\ScopeInterface::SCOPE_STORE, $storeId) ;
            $collectionTime = $this->_scopeConfig->getValue('deliveryoption/time_notice/time_collection',\Magento\Store\Model\ScopeInterface::SCOPE_STORE, $storeId) ;
            
            $day1 = $this->_scopeConfig->getValue('deliveryoption/time_notice/option',\Magento\Store\Model\ScopeInterface::SCOPE_STORE, $storeId) ;
            $day2 = $this->_scopeConfig->getValue('deliveryoption/time_notice/option1',\Magento\Store\Model\ScopeInterface::SCOPE_STORE, $storeId) ;
            $arrDay1 = explode(",",$day1);
            $arrDay2 = explode(",",$day2);
            $today = $this->date->date('w');
            if(in_array($today,$arrDay1)){
                $bonusTime = $this->_scopeConfig->getValue('deliveryoption/time_notice/time_delivery',\Magento\Store\Model\ScopeInterface::SCOPE_STORE, $storeId) ;
                $collectionTime = $this->_scopeConfig->getValue('deliveryoption/time_notice/time_collection',\Magento\Store\Model\ScopeInterface::SCOPE_STORE, $storeId) ;
            }
            if(in_array($today,$arrDay2)){
                $bonusTime = $this->_scopeConfig->getValue('deliveryoption/time_notice/time_delivery1',\Magento\Store\Model\ScopeInterface::SCOPE_STORE, $storeId) ;
                $collectionTime = $this->_scopeConfig->getValue('deliveryoption/time_notice/time_collection1',\Magento\Store\Model\ScopeInterface::SCOPE_STORE, $storeId) ;
            }
            
            $bonusTime = explode(",",$bonusTime);
            $collectionTime = explode(",",$collectionTime);
            $arrive_mess ='Delivery ';
            $collection_mess = 'Collection ';
            // $realTime = strtotime($time);
             $realTime = strtotime($order->getCreatedAt());
           
            $numberBonusTime = ((int)$bonusTime[0] * 60 * 60) + ((int)$bonusTime[1] * 60);
            $numberCollectionTime = ((int)$collectionTime[0] * 60 * 60) + ((int)$collectionTime[1] * 60);
            $hidedelivery= $this->_scopeConfig->getValue('other_configuration/hidedelivery/hidedelivery_option',\Magento\Store\Model\ScopeInterface::SCOPE_STORE) ;
            $collection_time_mes='customer has chosen collection time  ';
            $delivery_time_mes='customer has chosen delivery time  ';
    
            $dateBonusTime = date('h.i A', $realTime + $numberBonusTime);  
            $dateCollectionTime = date('h.i A', $realTime + $numberCollectionTime);
            if($order->getCustomerDeliveryTime()!= "0" && $hidedelivery!='1'){
                $timeasap= str_replace("_",":",$order->getCustomerDeliveryTime()?? '');
                $delivery_time = $timeasap ? substr($timeasap,-5):"";
    
                if($order->getShippingMethod() == 'freeshipping_freeshipping'){ 
                    $delivery_timeasap = $collection_time_mes.$delivery_time;
                }
                else{
                    $delivery_timeasap = $delivery_time_mes.$delivery_time;
                }
            }
            else{
                $delivery_timeasap="";
            }
           
            // Set current order details
            $total_item_count = "";
            $total_item_count = $order->getTotalItemCount();
           
            $separateMess = '';
            $fontsizedeliverytimeasap = $this->_scopeConfig->getValue('other_configuration/adjust_font_email/admin_delivery_collection_time',\Magento\Store\Model\ScopeInterface::SCOPE_STORE);
            $delivery_mess  = $order->getShippingMethod() == 'freeshipping_freeshipping' ? '<span id="orderType">' . $collection_mess . '</span>' . $separateMess . '<span id="orderTime">' . $dateCollectionTime . '</span>' : '<span id="orderType">' .$arrive_mess. '</span>' . $separateMess . '<span id="orderTime">' .$dateBonusTime . '</span>';
            $delivery_mess_new = '<h2 style="background-color:#F9EA02 !important;color:#000;margin-top: 0px !important;margin-bottom: 0px !important;font-size:'.$fontsizedeliverytimeasap.'px;padding:5px 5px;text-align: center;">'.$delivery_mess.'</h2>';
            
            $fontsizeaddressShipping = $this->_scopeConfig->getValue('other_configuration/adjust_font_email/admin_customer_address',\Magento\Store\Model\ScopeInterface::SCOPE_STORE);
            
            if($order->getShippingMethod() == 'freeshipping_freeshipping'){
                $addressShipping = $this->getFormattedShippingAddressCollect($order);
            
            }
            else{
                $addressShipping = $this->getFormattedShippingAddressDelivery($order);
          
            }
            $addressShipping_new = '<p style="font-size:'.$fontsizeaddressShipping.'px;margin:0 !important;width:273px !important;display: inline; font-weight: bold !important;">'.$addressShipping.'</p>';
            $paymentMethod = (string)$order->getPayment()->getMethodInstance()->getCode();
            $paymentTitle = "";
            $paymentInfo_new = "";
            if($paymentMethod == 'cashondelivery'){
                $paymentTitle = 'NOT PAID ';
                $paymentInfo ='NOT PAID';
                $paymentInfo_new ='NOT PAID';
            } else{
                $paymentTitle = $order->getStatus() == 'holded' ? 'ON HOLD-PAID' : 'PAID ';
                $paymentInfo =  $order->getStatus() == 'holded' ? 'ON HOLD-PAID' : 'PAID';
                $paymentInfo_new =  $order->getStatus() == 'holded' ? 'ON HOLD-PAID' : 'PAID';
                if($paymentMethod == 'checkmo'){
                    $paymentInfo_new = $order->getPayment()->getMethodInstance()->getTitle();
                }
                if($paymentMethod == 'checkmo' && $storeId =="10"){
                    $paymentInfo = $order->getPayment()->getMethodInstance()->getTitle();
                }
            }
            $postcode ="";
            
            if($order->getShippingMethod() == 'freeshipping_freeshipping'){
                $subject = "Collection ".$paymentTitle ;
    
            }else{
                $postcode = $order->getShippingAddress()->getPostcode()?$order->getShippingAddress()->getPostcode():"";
                $subject = "Delivery ".$paymentTitle ." ".$postcode;
            }
            $orderInfo = $this->collectionFactory->create()
            ->addAttributeToSelect('*')
            ->addFieldToFilter('customer_email', $order->getCustomerEmail());
            
            $resultPage = $this->_resultPageFactory->create();
            $itemcc = $resultPage->getLayout()->createBlock('\Magento\Framework\View\Element\Template')->setData('area','frontend')->setData('order',$order)->setTemplate('David_Config::email/itemsadmin.phtml')->toHtml();
            
            $item_new = $resultPage->getLayout()->createBlock('\Magento\Framework\View\Element\Template')->setData('area','frontend')->setData('order',$order)->setTemplate('David_Config::email/itemsadminstore.phtml')->toHtml();
         
            $templateId = $this->dataHelper->getConfigVal('sales_email/order/admin_template');
            // Set email template variables
            $vars = [
                'order' => $order,
                'subject'      => $subject,
                'arrive_mess'  => $arrive_mess,
                'arrive_date'  => $dateBonusTime,
                'collection_mess'  => $collection_mess,
                'collection_date'  => $dateCollectionTime,
                'delivery_mess' => $delivery_mess_new,
                'customcontent' => @$params['content'],
                'billing' => $order->getBillingAddress(),
                'payment_html' => $paymentInfo,
                'payment_html_new' => $paymentInfo_new,
                'store' => $order->getStore(),
                'formattedShippingAddress' => $addressShipping_new,
                'formattedBillingAddress' => $this->getFormattedBillingAddress($order),
                'created_at_formatted' => $order->getCreatedAtFormatted(2),
                'created_at_formatted_cus' => str_replace(',','',$order->getCreatedAtFormatted(3)),
                'grand_total' => $this->pricingHelper->currency(number_format($order->getGrandTotal(),2)),
                'email_customer_delivery_time'=> $delivery_timeasap,
                'order_comments' => $order->getBoldOrderComment(),
                'total_qty_order' => count($orderInfo),
                'item_list' => $itemcc,
                'item_new' => $item_new,
                'order_data' => [
                    'customer_name' => $order->getCustomerName(),
                    'is_not_virtual' => $order->getIsNotVirtual(),
                    'email_customer_note' => $order->getEmailCustomerNote(),
                    'frontend_status_label' => $order->getFrontendStatusLabel()  
                ]
            ];
            $this->_sendEmail($from, $to, $templateId, $vars, $store);
        }
	}
	
	protected function _sendEmail($from, $to, $templateId, $vars, $store, $area = \Magento\Framework\App\Area::AREA_FRONTEND) {
        $this->inlineTranslation->suspend();
        $this->_transportBuilder
                ->setTemplateIdentifier($templateId)
                ->setTemplateOptions([
                    'area' => $area,
                    'store' => $store->getId()
                ])
                ->setTemplateVars($vars)
                ->setFrom($from)
                ->addTo($to['email'], $to['name']);
        $transport = $this->_transportBuilder->getTransport();
        $transport->sendMessage();
        
        $this->inlineTranslation->resume();
        
        return true;
    }

    protected function getFormattedShippingAddress($order)
    {
        return $order->getIsVirtual()
            ? null
            : $this->addressRenderer->format($order->getShippingAddress(), 'html');
    }

    protected function getFormattedShippingAddressCollect($order)
    {
        return $order->getIsVirtual()
            ? null
            : $this->addressRenderer->format($order->getShippingAddress(), 'oneline');
    }

    protected function getFormattedShippingAddressDelivery($order)
    {
       
        return $order->getIsVirtual()
            ? null
            : $this->addressRenderer->format($order->getShippingAddress(), 'text');
    }
    
    protected function getFormattedBillingAddress($order)
    {
        return $this->addressRenderer->format($order->getBillingAddress(), 'html');
    }
}