<?php
namespace Magecomp\Firstdataicici\Controller\BillingAddress;
class Save extends \Magento\Framework\App\Action\Action
{
    protected $registry;
    public function __construct(
        \Magento\Framework\DataObjectFactory $dataObjectFactory,
        \Magento\Framework\App\CacheInterface $cache,
        \Magento\Framework\Serialize\Serializer\Json $serializer,
        \Magento\Framework\App\Action\Context $context

    ) {
        $this->dataObjectFactory = $dataObjectFactory;
        $this->cache = $cache;
        $this->serializer = $serializer ?: \Magento\Framework\App\ObjectManager::getInstance()->get(Json::class);
        parent::__construct($context);
    }
    
    public function execute()
    {
        $params = $this->getRequest()->getParams();
        $data = $params['name'];
        $data2 = $params['post'];
        $tags = null;
        $lifeTime = null;
        $identifier = 'test';
        $identifier2 = 'test2';
        $this->cache->save($data, $identifier);
        $this->cache->save($data2, $identifier2);
    }
}