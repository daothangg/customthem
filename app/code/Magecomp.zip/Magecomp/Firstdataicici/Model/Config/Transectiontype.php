<?php
namespace Magecomp\Firstdataicici\Model\Config;

class Transectiontype
{
    public function toOptionArray()
    {
        return [
            ['value'=>'payonly', 'label'=> __('PayOnly Mode')],
            ['value'=>'payplus', 'label'=> __('PayPlus Mode')],
            ['value'=>'fullpay', 'label'=> __('FullPay Mode')],
        ];
    }
}