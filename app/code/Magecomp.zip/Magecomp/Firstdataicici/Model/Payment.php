<?php
namespace Magecomp\Firstdataicici\Model;

class Payment extends \Magento\Payment\Model\Method\AbstractMethod
{
	protected $_code = 'firstdataicici';
    protected $_formBlockType = 'Magecomp\Firstdataicici\Block\Standard\Form';

    protected $_isGateway               = false;
    protected $_canAuthorize            = true;
    protected $_canCapture              = true;
    protected $_canCapturePartial       = false;
    protected $_canRefund               = false;
    protected $_canVoid                 = false;
    protected $_canUseInternal          = false;
    protected $_canUseCheckout          = true;
    protected $_canUseForMultishipping  = false;

    protected $_order = null;
	
	protected $urlBuilder;
	protected $_paymentData = null;
    protected $_moduleList;
    protected $checkoutSession;
    protected $_orderFactory;
	protected $_storeManager;
	protected $logger;
	protected $helper;
	protected $directory;
	
	public function __construct(
        \Magento\Framework\Model\Context $context,
        \Magento\Framework\Registry $registry,
        \Magento\Framework\Api\ExtensionAttributesFactory $extensionFactory,
        \Magento\Framework\Api\AttributeValueFactory $customAttributeFactory,
        \Magento\Payment\Helper\Data $paymentData,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Payment\Model\Method\Logger $logger,
        \Magento\Framework\Module\ModuleListInterface $moduleList,
        \Magento\Framework\Stdlib\DateTime\TimezoneInterface $localeDate,
        \Magento\Sales\Model\OrderFactory $orderFactory,
		\Magecomp\Firstdataicici\Helper\Data $helper,
		\Magento\Directory\Model\Country $directory,
        \Magento\Framework\Url $urlBuilder,
        \Magento\Checkout\Model\Session $checkoutSession,
		\Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Framework\Model\ResourceModel\AbstractResource $resource = null,
        \Magento\Framework\Data\Collection\AbstractDb $resourceCollection = null,
		array $data = []
    ) {
		$this->urlBuilder = $urlBuilder;
		$this->_moduleList = $moduleList;
        $this->_scopeConfig = $scopeConfig;
        $this->checkoutSession = $checkoutSession;
		$this->_storeManager = $storeManager;
		$this->logger = $logger;
		$this->helper = $helper;
		$this->directory =$directory;
        parent::__construct($context,
            $registry,
            $extensionFactory,			
            $customAttributeFactory,
			$paymentData,
            $scopeConfig,
            $logger,
            $resource,
            $resourceCollection,
            $data
        );
    }

    public function validate()
    {
        parent::validate();
        $paymentInfo = $this->getInfoInstance();		
	
        return $this;
    }

    public function capture(\Magento\Payment\Model\InfoInterface $payment, $amount)
    {
        $payment->setStatus(self::STATUS_APPROVED)
            ->setLastTransId($this->getTransactionId());

        return $this;
    }

    public function getSuccessURL()
    {
		return $this->urlBuilder->getUrl('firstdataicici/standard/success', ['_secure' => true]);
    }

    public function getFailureURL()
    {
		return $this->urlBuilder->getUrl('firstdataicici/standard/failure', ['_secure' => true]);
    }

    public function getOrderPlaceRedirectUrl()
    {
		return $this->urlBuilder->getUrl('firstdataicici/standard/redirect', ['_secure' => true]);
	}

	public function order(\Magento\Payment\Model\InfoInterface $payment, $amount){
        if (!$this->canOrder()) {
            throw new \Magento\Framework\Exception\LocalizedException(__('The order action is not available.'));
        }
        return $this;
    }
    public function getCurrentTimezone()
    {
        return $this->helper->getCurrentTimezone();
    }
    public function getGatewayUrl()
    {
        if($this->helper->getTransactionMode()==1)
            return "https://test.ipg-online.com/connect/gateway/processing";
        else
            return "https://www.ipg-online.com/connect/gateway/processing";
    }

    public function getDateTime() {
        date_default_timezone_set('Europe/London');
        $dateTime= date('Y:m:d-H:i:s');
        return $dateTime;
    }
    public function createHash($chargetotal,$Currency)
    {
        $storeId = $this->helper->getICIStoreId();
        $sharedSecret = $this->helper->getSecretKey();

        $stringToHash = $storeId . $this->getDateTime() . $chargetotal . $Currency . $sharedSecret;
        $ascii = bin2hex($stringToHash);

        return sha1($ascii);
    }
    public function getStandardCheckoutFormFields()
    {
        $order = $this->getOrder();

        if (!($order instanceof \Magento\Sales\Model\Order)) {
            throw new \Magento\Framework\Exception\LocalizedException(__('Cannot retrieve order object'));
        }

        $secret_key = $this->helper->getSecretKey();
        $transmodetype=$this->helper->getTransactionType();
        $iciStoreId= $this->helper->getICIStoreId();
        $amount=number_format($order->getBaseGrandTotal(), 2, '.', '');
        $orderId=$order->getRealOrderId();
        $language = strtolower($this->helper->getLanguage());

        $billingAddress = $order->getBillingAddress();
        if ($order->getCustomerEmail()) {
            $email = $order->getCustomerEmail();
        } elseif ($billingAddress->getEmail()) {
            $email = $billingAddress->getEmail();
        } else {
            $email = '';
        }
        $fields = array(
            'timezone'      => 'GMT',
            'authenticateTransaction'   => "true",
            'txntype'       => "sale",
            'txndatetime'   => $this->getDateTime(),
            'hash'          => $this->createHash($amount,"826"),
            'currency'      => 'GBP',
            'mode'          => $transmodetype,
            'storename'     => $iciStoreId,
            'chargetotal'   => $amount,
            'paymentMethod' => "payonline",
            'sharedsecret'  => $secret_key,
            'email'         => $email,
            'oid'           => $orderId,
            'language'      => 'en_GB',
            'responseSuccessURL'    => $this->getSuccessURL(),
            'responseFailURL'       =>$this->getFailureURL(),                       
            'checkoutoption'        =>'combinedpage',           
            'hash_algorithm'    =>"SHA1",
            'bname'         =>$billingAddress->getFirstname(),
            'bzip'          => $billingAddress->getPostcode(),
            'bcountry'      => 'GBP',
            'bcity'         => $billingAddress->getCity()
        );

        return $fields;
    }
}